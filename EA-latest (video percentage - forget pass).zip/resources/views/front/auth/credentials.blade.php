<h3>Email: {{ $userDetails->email }}</h3>
<h3>CRM Code: {{ $userDetails->crm_code }}</h3>
<h3>Password: {{ $userPassword ? $userPassword->password : '' }}</h3>
