<div class="logo-footer">
    <div class="footer-logo"><img src="{{ asset('storage/images/logos/AP_Logo.png') }}" class="mw-100" alt=""></div>
</div>
