<div class="logo-footer empty py-3">
    <img src="{{ asset('storage/images/logos/AP_Logo.png') }}" style="height: 25px;" alt="">
</div>

