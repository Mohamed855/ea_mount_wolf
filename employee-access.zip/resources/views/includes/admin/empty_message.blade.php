<tr>
    <td colspan="7">
        <h4 class="p-3">
            Empty
        </h4>
    </td>
</tr>
